package com.hunttracker.mobile;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.os.*;
import org.json.*;
import java.util.*;

public class TrackingService extends Service implements LocationListener {
 public static final String START="com.hunttracker.mobile.START_TRACK";
 public static final String STOP="com.hunttracker.mobile.STOP_TRACK";
 public static final String DISCARD="com.hunttracker.mobile.DISCARD_TRACK";
 private static final String CHANNEL="hunttracker_gps",PREF="native_gps";
 private LocationManager lm;
 private boolean recording=false;
 private JSONArray points=new JSONArray();
 private long lastTime=0;
 private Location lastLocation;
 @Override public void onCreate(){super.onCreate();lm=(LocationManager)getSystemService(LOCATION_SERVICE);
  NotificationChannel channel=new NotificationChannel(CHANNEL,"Hunt Tracker GPS",NotificationManager.IMPORTANCE_LOW);
  channel.setDescription("Active hunting route recording");
  ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
 }
 private Notification notification(){
  Intent open=new Intent(this,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
  PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_mylocation)
   .setContentTitle("Hunt Tracker recording route").setContentText("GPS tracking continues with screen locked · tap to open")
   .setOngoing(true).setContentIntent(pi).build();
 }
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  String action=intent==null?"":intent.getAction();
  if(STOP.equals(action)||DISCARD.equals(action)){
   boolean save=STOP.equals(action);
   stopUpdates();
   if(save)persistCompleted();else getSharedPreferences(PREF,MODE_PRIVATE).edit().remove("active").apply();
   stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;
  }
  if(!START.equals(action)){stopSelf();return START_NOT_STICKY;}
  if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED
    &&checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){stopSelf();return START_NOT_STICKY;}
  points=new JSONArray();lastLocation=null;lastTime=0;recording=true;
  String name=intent.getStringExtra("name");getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("name",name==null?"GPS Track":name).putString("active","[]").apply();
  startForeground(101,notification(),android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
  try{lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,3000,4,this,Looper.getMainLooper());
    if(lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,5000,10,this,Looper.getMainLooper());
  }catch(SecurityException ex){stopUpdates();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
  return START_NOT_STICKY;
 }
 @Override public void onLocationChanged(Location l){
  if(!recording||l==null||!l.hasAccuracy()||l.getAccuracy()>100)return;
  if(lastLocation!=null&&l.distanceTo(lastLocation)<5&&System.currentTimeMillis()-lastTime<15000)return;
  lastLocation=l;lastTime=System.currentTimeMillis();
  JSONArray pair=new JSONArray();pair.put(l.getLatitude());pair.put(l.getLongitude());points.put(pair);
  getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("active",points.toString()).apply();
 }
 private void persistCompleted(){
  android.content.SharedPreferences prefs=getSharedPreferences(PREF,MODE_PRIVATE);
  String raw=prefs.getString("active","[]");
  try{
   JSONArray p=new JSONArray(raw);
   if(p.length()>0){
    JSONArray all=new JSONArray(prefs.getString("completed","[]"));
    JSONObject track=new JSONObject();
    track.put("id","native-"+System.currentTimeMillis());track.put("name",prefs.getString("name","GPS Track"));
    track.put("createdAt",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US){{setTimeZone(TimeZone.getTimeZone("UTC"));}}.format(new Date()));
    track.put("points",p);all.put(track);prefs.edit().putString("completed",all.toString()).remove("active").apply();
   }else prefs.edit().remove("active").apply();
  }catch(JSONException ignored){}
 }
 private void stopUpdates(){recording=false;if(lm!=null)lm.removeUpdates(this);}
 @Override public void onDestroy(){stopUpdates();super.onDestroy();}
 @Override public IBinder onBind(Intent intent){return null;}
}
