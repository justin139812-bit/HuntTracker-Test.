package com.hunttracker.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.webkit.PermissionRequest;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.content.Context;
import android.os.Build;
import android.content.pm.ServiceInfo;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

public class MainActivity extends Activity {
 private WebView webView;
 private GeolocationPermissions.Callback pendingGeo;
 private String pendingOrigin;
 private static final int LOCATION_REQUEST=101;
 private static final String HOME="https://appassets.androidplatform.net/assets/boundaries.html";
 @Override public void onCreate(Bundle state){super.onCreate(state);
  getWindow().setStatusBarColor(0xff11191d);getWindow().setNavigationBarColor(0xff11191d);
  webView=new WebView(this);setContentView(webView);
  webView.addJavascriptInterface(new TrackingBridge(),"HuntTrackerNative");
  WebSettings settings=webView.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setGeolocationEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setBuiltInZoomControls(false);
  WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
  webView.setWebViewClient(new WebViewClientCompat(){
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){return loader.shouldInterceptRequest(request.getUrl());}
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
    Uri url=request.getUrl();String host=url.getHost();
    if("appassets.androidplatform.net".equals(host))return false;
    if("http".equals(url.getScheme())||"https".equals(url.getScheme())){startActivity(new Intent(Intent.ACTION_VIEW,url));return true;}
    return true;
   }
  });
  webView.setWebChromeClient(new WebChromeClient(){
   @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback callback){
    if(!"https://appassets.androidplatform.net".equals(origin)){callback.invoke(origin,false,false);return;}
    if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){callback.invoke(origin,true,false);return;}
    pendingGeo=callback;pendingOrigin=origin;
    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_REQUEST);
   }
  });
  if(state==null)webView.loadUrl(HOME);else webView.restoreState(state);
 }
 @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);
  if(requestCode==LOCATION_REQUEST&&pendingGeo!=null){boolean granted=false;for(int r:results)if(r==PackageManager.PERMISSION_GRANTED)granted=true;
   pendingGeo.invoke(pendingOrigin,granted,false);pendingGeo=null;pendingOrigin=null;
   if(!granted)Toast.makeText(this,"Enable location permission in Android Settings to use GPS",Toast.LENGTH_LONG).show();
  }
 }

 public class TrackingBridge {
  @JavascriptInterface public void start(String name){
   runOnUiThread(()->{
    if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED
     &&checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
      Toast.makeText(MainActivity.this,"Allow location permission, then tap Track again",Toast.LENGTH_LONG).show();
      requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_REQUEST);
      return;
    }
    if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},103);
    Intent i=new Intent(MainActivity.this,TrackingService.class);i.setAction(TrackingService.START);i.putExtra("name",name);
    try{startForegroundService(i);}catch(Exception e){Toast.makeText(MainActivity.this,"Unable to start GPS: "+e.getMessage(),Toast.LENGTH_LONG).show();}
   });
  }
  @JavascriptInterface public void stop(boolean save){
   runOnUiThread(()->{
    Intent i=new Intent(MainActivity.this,TrackingService.class);i.setAction(save?TrackingService.STOP:TrackingService.DISCARD);
    startService(i);
   });
  }
  @JavascriptInterface public String state(){
   android.content.SharedPreferences pref=getSharedPreferences("native_gps",MODE_PRIVATE);
   String active=pref.getString("active",null);
   return "{\"active\":"+(active==null?"false":"true")+",\"points\":"+(active==null?"[]":active)+"}";
  }
  @JavascriptInterface public String drainCompleted(){
   android.content.SharedPreferences pref=getSharedPreferences("native_gps",MODE_PRIVATE);
   String result=pref.getString("completed","[]");pref.edit().remove("completed").apply();return result;
  }
 }
 @Override protected void onResume(){super.onResume();if(webView!=null)webView.evaluateJavascript("window.syncNativeTracks&&window.syncNativeTracks()",null);}
 @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
 @Override protected void onSaveInstanceState(Bundle out){webView.saveState(out);super.onSaveInstanceState(out);}
 @Override protected void onDestroy(){webView.destroy();super.onDestroy();}
}
