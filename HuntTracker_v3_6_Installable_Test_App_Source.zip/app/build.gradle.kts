plugins { id("com.android.application") }
android {
 namespace = "com.hunttracker.mobile"
 compileSdk = 35
 defaultConfig { applicationId = "com.hunttracker.mobile.test"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "3.6-test" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
dependencies { implementation("androidx.webkit:webkit:1.12.1") }
