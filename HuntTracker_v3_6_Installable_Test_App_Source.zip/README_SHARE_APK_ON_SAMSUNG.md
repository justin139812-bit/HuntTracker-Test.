# Hunt Tracker — shareable Android APK

This ZIP is an Android source project, NOT an APK. GitHub Actions builds an APK for you.

## Build on your Samsung without a computer
1. Create a **public** GitHub repository named `HuntTracker-Android` (a public repo lets friends download releases). Do not upload personal property coordinates or secret credentials to the repository.
2. Upload the **extracted project files**, preserving nested folders, including `.github/workflows/build-apk.yml`. GitHub mobile web may require **Desktop site**; GitHub does not automatically unpack a ZIP uploaded as a file.
3. Open the repository **Actions** tab > **Build and Share Hunt Tracker APK** > **Run workflow**.
4. Open the completed run > **Artifacts** > `HuntTracker-Android-APK` to download a ZIP containing `HuntTracker-Android.apk`. Extract it, then tap the APK to install on Samsung. This artifact link is for people with access to the GitHub workflow; it is not a convenient public share link.

## Make a link anyone can use
1. In the GitHub repository, open **Releases** > **Draft a new release**.
2. Create a new tag named `v1.0.0` and publish the release (you can leave it without an APK initially).
3. GitHub Actions runs automatically on the `v1.0.0` tag and tries to attach `HuntTracker-Android.apk` to that release. **If you published the release before the workflow, the workflow's `gh release create` step will fail because the release exists**. Instead, create a tag without first publishing a release, using the GitHub website's tag creation interface if available, or use GitHub Actions artifact and manually upload the APK file to a release from your phone.
4. After a successful tagged build, share the public GitHub Releases link with friends. They can download the APK and install it; Android will ask them to allow installation from that source.

**Simplest public sharing:** Build once with Run workflow, download/extract the APK, then create a GitHub Release in your public repository and upload `HuntTracker-Android.apk` as a release asset. Share that release URL. This does not require a tagged workflow.

**Important:** The APK is a debug-signed test app. It has not been built or tested here. It is not ready for Google Play or commercial distribution. The embedded map needs internet for satellite imagery. Data saved in the APK stays on each person's phone; sharing the APK does **not** share property maps or markers between hunters. If you want hunters to share properties and invite partners, that requires a separate secure sync/invitation feature.
