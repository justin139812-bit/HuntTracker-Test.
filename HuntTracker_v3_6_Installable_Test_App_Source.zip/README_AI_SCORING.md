# Hunt Tracker v3.5 — Photo + Manual Scoring

The scoring screen now has separate Photo / AI-assisted and Manual scoring modes.

**Working now:** upload up to 6 photos, preview/remove photos, manually enter seven antler measurement totals, calculate an approximate gross typical field score and user-entered net adjustments, save/edit buck profiles, export JSON backups. Whitetail and mule deer are supported as approximate field estimates.

**Not connected:** actual AI photo inference. The Analyze Photos button honestly reports that a secure service is needed. AI_ENDPOINT in scoring.html is intentionally blank. Do not put secret API keys in the Android assets or browser JS. To activate, deploy a secure HTTPS backend that authenticates requests, limits abuse, invokes a vision model, validates a response containing seven nonnegative numeric measurements (spread,leftBeam,rightBeam,leftTines,rightTines,leftMass,rightMass), and clearly communicates image-scale uncertainty. The app can then populate editable fields; users must review and calculate manually. AI model measurements may be highly unreliable without known scale/multiple views.

No APK has been compiled. The source project has only passed JavaScript syntax and ZIP integrity checks. Scores are not official Boone & Crockett scores.
