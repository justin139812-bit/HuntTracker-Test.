# Hunt Tracker v3.3 — Roads and GPS Tracking
- Property map: tap Road, tap 2+ points, then Save Road. Yellow lines show saved roads/trails.
- GPS Track: tap Track, allow location, keep map open, move, then tap Track again to Stop & Save. Green live path; saved tracks in cyan.
- My GPS finds position; markers and existing property boundaries remain supported.
- Open Show tools > Roads & Trails / GPS Tracking to name, view, delete routes.
- Export Property & Markers now exports properties, equipment, roads, and GPS tracks as GeoJSON.
- GPS tracking requires a phone with location enabled and a secure browser origin or appropriate Android WebView geolocation permissions.
- Tracking is foreground only: do not lock the screen, leave the app, or assume background recording. GPS points with accuracy worse than 100 m are rejected; path distance is approximate, not surveyed.
- Data stays on the device in localStorage. Back up using GeoJSON export before uninstalling or clearing app data.
- This is an Android source project, not a compiled APK.
