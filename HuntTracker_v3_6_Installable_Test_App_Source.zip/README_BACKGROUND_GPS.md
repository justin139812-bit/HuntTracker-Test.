Hunt Tracker v3.4 — Android screen-locked GPS tracking

When running as the compiled Android app, Track starts an Android foreground location service with a persistent notification. The GPS service continues while the screen is locked, and stores points in native SharedPreferences. Stop & Save writes a completed route; the map imports saved routes on resume. The native app must be launched and GPS permission granted before locking. Android may stop tracking if permissions are revoked, location is turned off, battery restrictions are severe, or the user force-stops the app. This does not enable background location permission or hidden tracking.

When the same HTML is opened as a normal website, tracking remains foreground-only. Do not rely on the website to track with the screen locked.

Build using GitHub Actions. This is SOURCE CODE, not a compiled APK. Test on a physical Android device before relying on tracks. Always export data before clearing app storage.
