# Hunt Tracker TEST v3.6 (separate Android app)
This is a **buildable Android source project**, NOT a compiled APK.
The test app installs as **Hunt Tracker TEST**, separately from the production app (different applicationId).
## Build from a phone with GitHub
1. Create a new GitHub repository, for example `HuntTracker-Test`.
2. Upload **all the files and folders inside this ZIP** to the root of the repository, including `.github/workflows/build-apk.yml`. GitHub's browser uploader may hide dot-folders; verify `.github` is present.
3. In the repository, tap **Actions** → **Build Hunt Tracker TEST APK** → **Run workflow**. The workflow also runs on push to `main`.
4. When the build succeeds, open its run → **Artifacts** → **HuntTracker-TEST-APK**. Download and extract the artifact ZIP to find `HuntTracker-TEST-v3.6.apk`.
5. Install the APK on Samsung. Android may ask you to allow installing unknown apps for the app used to open the APK. Only install your own trusted build.
6. Launch **Hunt Tracker TEST** → Property Map → Boundary → tap 3+ corners → Save Boundary. Test Road, GPS and equipment separately.
## Notes
- Satellite tiles and Leaflet libraries require an internet connection.
- GPS permission is requested by Android. A blue dot requires location services and permission.
- The test app stores data separately from the production app. Removing the test app deletes its saved data unless exported.
- Manual scoring is available; real AI photo analysis is NOT connected.
- GPS tracking with screen locked is experimental and must be tested outdoors; the app may be stopped by Android restrictions.
- Property outlines are approximate and are not legal surveys.
- A successful source ZIP / JS check does not prove the APK will compile or run on a device.
