HUNT TRACKER v3.2 - SIGHTINGS COUNT UPDATE

In Game Sightings, choose any species and enter separate Buck, Doe, and Fawn counts. Total is calculated automatically. Save a GPS pin and the sighting; saved logs and map pin popups show the counts. Existing sightings remain readable. All counts are 0-9999 and at least one animal must be entered for a new record. Counts use buck/doe/fawn terminology for every species as requested; some species use different biological names.

This is Android source project for GitHub Actions build, not a compiled APK. Upload the extracted project files to GitHub, including the hidden .github folder. Do not upload the ZIP as a single file.
