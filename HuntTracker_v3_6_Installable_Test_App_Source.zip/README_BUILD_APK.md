# Hunt Tracker — Android APK project

This is a **real Android Studio project** that wraps the Hunt Tracker v3.1 map in a native Android WebView, with bundled local HTML, native location permissions, and access to live satellite tiles over the internet. **This ZIP is source code, not an installable APK.**

## Build using Android Studio on a computer
1. Extract ZIP and open the `HuntTracker_Android_APK_Project` folder in Android Studio.
2. Let Gradle sync (internet required).
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install `app/build/outputs/apk/debug/app-debug.apk` on your Samsung.

## Build from a phone with GitHub Actions (no computer)
1. Sign in to GitHub in your phone browser, create a **private repository**.
2. Upload the **contents** of this ZIP into the repository, preserving the folder structure, including `.github/workflows/build-apk.yml`. GitHub's mobile browser upload may require Desktop site mode; uploading nested folders from a phone can be difficult.
3. Open **Actions > Build Hunt Tracker APK > Run workflow**. Alternatively, pushing to `main` triggers a build.
4. After the workflow succeeds, open the run, download **HuntTracker-Android-APK** artifact, extract it and tap `app-debug.apk` to install. Android may ask you to allow installs from your browser/files app.

The debug APK is suitable for personal testing, not Google Play distribution. The GitHub Actions build has **not** been executed here; dependency availability and runtime behavior still require verification. Maps require internet. App data in this APK is separate from data saved in your Netlify website; there is no automatic transfer. The app's embedded local pages are served under a secure Android asset domain, allowing browser geolocation with native permission. The app is not a fully native map implementation.
